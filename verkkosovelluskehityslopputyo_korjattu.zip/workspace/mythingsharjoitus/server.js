// Verkkosovelluskehityksen lopputyö

var mysql = require('mysql');
var connection = mysql.createConnection({
  host  : 'localhost',
  user  : 'root',
  password : '',
  database : 'c9'
});
var bodyParser= require('body-parser');
const express = require('express'); 				        // luodaan app expressillä
const app = express();
const port = process.env.port || 8080; 				      // määrätään portti ohjelmalle

connection.connect(function(err){
    if(err){
        console.log('DB connection error');
    }
    else{
        console.log('DB connection ok');
    }
    
});

app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing       application/x-www-form-urlencoded

// application
app.get('/', function (req, res) {
  res.sendFile(__dirname + '/client/index.html'); // Ladataan sivusto
});

// REST API jolla noudetaan olemassa olevat tiedot
app.get('/api/things', function (req, res) {
  connection.query('SELECT id, name, description, latitude, longitude FROM things', function (err, rows, fields){
    if(err) throw err;
    var palautus = [];
    for (var i = 0; i < rows.length; i++ ) {
      palautus.push({id: rows[i].id, name : rows[i].name, description : rows[i].description, location : { latitude : rows[i].latitude, longitude : rows[i].longitude}});
      
    }
    res.json(palautus);
    console.log(rows);
  });
});


// REST uuden laitteen lisääminen
app.post('/api/addthing', function (req, res){
  
  console.log(req);
   var thinginfo = {
      
        name : req.body.thingname,
        description : req.body.thingdesc,
        latitude : parseFloat(req.body.thinglat),
        longitude : parseFloat(req.body.thinglong)
    };
    
    console.log(thinginfo);
    
    connection.query('INSERT INTO things SET ?', thinginfo,  function(error){
      if(error){
              console.log(error.message);
              res.sendStatus(400)
      }
      else{
          console.log('Thing added successfully');
          res.sendStatus(200)
      }
    });
});

//REST laitteen poistaminen nimen perusteella
app.post('/api/deletething', function (req,res){
  
  var name = req.body.deletethingname
  
  console.log(name);
  
  connection.query('DELETE FROM things WHERE NAME = ?', name, function(error){
     if(error){
              console.log(error.message);
              res.sendStatus(400)
      }
      else{
          console.log('Thing deleted successfully');
          res.sendStatus(200)
      }
    });
});


//REST laitteen tietojen päivittäminen
app.post('/api/updatething', function (req, res){
  
  
   var id = req.body.thingid;
   console.log(id);
   var thingupdateinfo = {
      
        name : req.body.updatethingname,
        description : req.body.updatethingdesc,
        latitude : parseFloat(req.body.updatethinglat),
        longitude : parseFloat(req.body.updatethinglong)
    };
    
    console.log(thingupdateinfo);
    
    connection.query("UPDATE things SET ? WHERE id = '"+id+"'", thingupdateinfo,  function(error){
      if(error){
              console.log(error.message);
              res.sendStatus(400)
      }
      else{
          console.log('Thing updated successfully');
          res.sendStatus(200)
      }
    });
});


/*
app.post('/view1', function(req, res) {
    console.log(req);
    res.end();
});
*/

// Ohjataan staattisten resurssien sijainnit esim. html ja css
app.use(express.static('client'));

// Laitetaan ohjelma kuuntelemaan määrättyä porttia (käynnistys: node server.js)
app.listen(port);
console.log("MyThings app listening on port " + port);
    