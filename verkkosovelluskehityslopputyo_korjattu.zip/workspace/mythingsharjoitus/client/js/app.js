//ohjesivu: https://developers.google.com/maps/documentation/javascript/examples/infowindow-simple

// Define the `thingsApp` module
var thingsApp = angular.module('thingsApp', []);

// Define the `PhoneListController` controller on the `phonecatApp` module
thingsApp.controller('ThingListController', function ThingListController($scope, $http, $httpParamSerializerJQLike) {

  // View and Model communicate through $scope attributes, for instance $scope.phones
  $scope.title = "My things app";  // jne
  
  
 
    $scope.getthings = function () {
       $http.get("/api/things")
        .then(function(response) {
           $scope.things = response.data;
          });
    }
    $scope.getthings();
    
  $scope.addthingtodb = function() {
   
   /*$http.post('/view1',$scope.formData).
        success(function(data) {
            console.log("posted successfully");
        }).error(function(data) {
            console.error("error in posting");
        })
   */
   
   $http.post('/api/addthing',$scope.banaani).
        success(function(data) {
            console.log("posted successfully");
            $scope.getthings();
            $scope.initMarkers();
        }).error(function(data) {
            console.error("error in posting");
        })
   
    
    /*var pyynto = {
      
        name : $scope.thingname,
        description : $scope.thingdesc,
        latitude : $scope.thinglat,
        longitude : $scope.thinglong
    }
    
    $http({
      url : '/api/addthing',
      headers : {'Content-Type':'application/json'},
      method : 'POST',
      data : $httpParamSerializerJQLike(pyynto)
    })
    .then(function(response) {
        console.log(response);
    });
    
    console.log(pyynto);*/
  };
  
  $scope.updatethingindb = function() {
    
    $http.post('/api/updatething',$scope.banaani).
        success(function(data) {
            console.log("posted successfully");
            $scope.getthings();
            $scope.initMarkers();
        }).error(function(data) {
            console.error("error in posting");
        })
    
  };
  
  $scope.deletethingfromdb = function() {
    
    $http.post('/api/deletething',$scope.banaani).
        success(function(data) {
            console.log("posted successfully");
            $scope.getthings();
            $scope.initMarkers();
        }).error(function(data) {
            console.error("error in posting");
        })
    
  };
  
  $scope.markers = [];
  
  
  
  $scope.initMarkers = function() {
    if ($scope.things != undefined) {
        for (var i = 0; i < $scope.things.length; i++ ) {
        var thing = $scope.things[i];
        
        
        
        function MARKER () {
          
          var marker = new google.maps.Marker({
            position: {lat : parseFloat(thing.location.latitude),
                        lng : parseFloat(thing.location.longitude)},
            map: $scope.map,
            title: thing.name,
            });
            
            var contentString = '<IMG BORDER="0" style="height: 50px; width: 50px; object-fit: contain" ALIGN="Left" SRC="http://efdreams.com/data_images/dreams/telephone/telephone-01.jpg">'+$scope.things[i].description;

            var infowindow = new google.maps.InfoWindow({
              content: contentString,
              maxWidth: 150
            });

            marker.addListener('click', function () {
               infowindow.open($scope.map, marker);
            });
        }
        
        
        
        
        $scope.markers.push(
          MARKER()
          /*
          new google.maps.Marker({
            position: {lat : parseFloat(thing.location.latitude),
                        lng : parseFloat(thing.location.longitude)},
            map: $scope.map,
            title: thing.name
           
            
          })*/
        );
      };
    } 
    else 
    {
      setTimeout(function() { $scope.initMarkers(); }, 250);
    }
  }
  
   $scope.refreshmap = function () {
       $scope.initMarkers();
       console.log($scope.markers);
    }
  
  
});

// Init google maps
// bind to main window window (body id=MainWrap)



function initMap() {
  
  var map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: 62.596, lng: 29.777},
    zoom: 8
  });
 
  angular.element(document.getElementById('MainWrap')).scope().map = map;
  
  angular.element(document.getElementById('MainWrap')).scope().initMarkers();

};


